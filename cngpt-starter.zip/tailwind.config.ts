import type { Config } from 'tailwindcss'

const config: Config = {
  darkMode: ["class"],
  content: [
    "./src/pages/**/*.{ts,tsx}",
    "./src/components/**/*.{ts,tsx}",
    "./src/app/**/*.{ts,tsx}"
  ],
  theme: {
    extend: {
      colors: {
        cardic: {
          bg: "#020617",
          primary: "#0ea5e9",
          accent: "#f59e0b",
          gold: "#fbbf24"
        }
      },
      boxShadow: {
        glow: "0 0 30px rgba(14,165,233,0.25)"
      }
    }
  },
  plugins: []
}
export default config
