import { NextRequest, NextResponse } from 'next/server'

export async function POST(req: NextRequest) {
  const { prompt } = await req.json()
  const reply = `Here’s a concise, neutral explanation with steps and a risk note for: "${prompt}"\n\n1) Concept: ...\n2) Example: ...\n3) Steps: ...\n4) Common mistakes: ...\n\nAction: Try to identify bias, levels, and invalidation on today’s chart.\nRisk: Education only; never risk what you can’t afford to lose.`
  return NextResponse.json({ reply })
}
