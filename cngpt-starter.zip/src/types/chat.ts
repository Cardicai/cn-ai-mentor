import { z } from 'zod'

export const MessageSchema = z.object({
  id: z.string(),
  role: z.enum(['user', 'mentor']),
  type: z.enum(['text', 'image', 'audio']).default('text'),
  content: z.string(),
  createdAt: z.number(),
  meta: z.record(z.any()).optional()
})
export type Message = z.infer<typeof MessageSchema>

export const TopicSchema = z.object({
  id: z.string(),
  title: z.string().min(1),
  createdAt: z.number(),
  lastAt: z.number()
})
export type Topic = z.infer<typeof TopicSchema>
