'use client'
import { useCallback, useEffect, useMemo, useState } from 'react'
import { Message, Topic } from '@/types/chat'

const STORAGE_KEY = 'cngpt_topics_v1'
const MESSAGES_KEY = 'cngpt_messages_v1'

function now() { return Date.now() }

export function useTopics() {
  const [topics, setTopics] = useState<Topic[]>([])
  const [messagesMap, setMessagesMap] = useState<Record<string, Message[]>>({})

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY)
      const msgs = localStorage.getItem(MESSAGES_KEY)
      if (raw) {
        const parsed = JSON.parse(raw)
        if (Array.isArray(parsed)) setTopics(parsed)
      }
      if (msgs) {
        const parsed = JSON.parse(msgs)
        if (parsed && typeof parsed === 'object') setMessagesMap(parsed)
      }
    } catch (e) { console.warn('Failed to load topics', e) }
  }, [])

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(topics))
      localStorage.setItem(MESSAGES_KEY, JSON.stringify(messagesMap))
    } catch (e) { console.warn('Failed to save', e) }
  }, [topics, messagesMap])

  const createTopic = useCallback((title: string) => {
    const id = `t_${Math.random().toString(36).slice(2, 9)}`
    const t: Topic = { id, title, createdAt: now(), lastAt: now() }
    setTopics(prev => [t, ...prev])
    setMessagesMap(prev => ({ ...prev, [id]: [] }))
    return t
  }, [])

  const deleteTopic = useCallback((id: string) => {
    setTopics(prev => prev.filter(t => t.id !== id))
    setMessagesMap(prev => { const c = { ...prev }; delete c[id]; return c })
  }, [])

  const renameTopic = useCallback((id: string, title: string) => {
    setTopics(prev => prev.map(t => t.id === id ? { ...t, title } : t))
  }, [])

  const addMessage = useCallback((topicId: string, message: Message) => {
    setMessagesMap(prev => {
      const copy = { ...prev }
      const arr = copy[topicId] ?? []
      copy[topicId] = [...arr, message]
      return copy
    })
    setTopics(prev => prev.map(t => t.id === topicId ? { ...t, lastAt: now() } : t))
  }, [])

  const getMessages = useCallback((topicId: string) => {
    return messagesMap[topicId] ?? []
  }, [messagesMap])

  const listTopics = useMemo(() => {
    return [...topics].sort((a,b) => b.lastAt - a.lastAt)
  }, [topics])

  const seedIfEmpty = useCallback(() => {
    if (topics.length === 0) {
      const firstId = `t_${Math.random().toString(36).slice(2,9)}`
      const t = { id: firstId, title: 'Getting started', createdAt: now(), lastAt: now() }
      const sampleMsg = {
        id: `m_${Math.random().toString(36).slice(2,9)}`,
        role: 'mentor' as const,
        type: 'text' as const,
        content: 'Welcome — this is your first topic. Ask anything about trading or create a new topic from History.',
        createdAt: now()
      }
      setTopics([t])
      setMessagesMap({ [firstId]: [sampleMsg] })
    }
  }, [topics.length])

  return { topics: listTopics, createTopic, deleteTopic, renameTopic, addMessage, getMessages, seedIfEmpty } as const
}
